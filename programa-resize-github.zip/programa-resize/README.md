# Programa Resize

Programa para acompanhar as folhas de corte (Resize) a partir do ficheiro **Resize.xlsx** do SharePoint (site PI).

O programa **não guarda dados neste repositório**. Lê e grava apenas o Resize.xlsx sincronizado no computador de cada utilizador.

## Usar

1. Sincronizar a biblioteca *Documents* do site **PI** no SharePoint (botão **Sync**).
2. Abrir o programa (página do GitHub Pages ou `index.html`) no **Edge** ou **Chrome**.
3. Carregar em **⟳ Ligar ao Resize.xlsx** e escolher o Resize.xlsx da pasta sincronizada (só da primeira vez).
4. O programa atualiza-se sozinho quando o Excel muda.
5. **Recebido** grava `CSP1` (verde) na coluna X; **Entregue ao prestador** grava `Prestador` (amarelo).

## Pastas

| Pasta | Conteúdo |
|---|---|
| `index.html` | O programa (tudo num ficheiro, funciona sem internet) |
| `sap/` | Script `ME21N - Requisicao.vbs` e atalho `.sap` (SAP PRO, mandante 100) |
| `excel/` | Office Scripts *Recebido* e *Entregue ao prestador* para o Excel na Web |

## Atualizar o programa

Substituir o `index.html` por uma versão nova (Add file → Upload files → Commit).
Com o GitHub Pages ativo, todos recebem a versão nova ao recarregar a página.
