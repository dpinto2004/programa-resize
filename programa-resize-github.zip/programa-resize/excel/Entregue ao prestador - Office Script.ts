// Office Script "Entregue ao prestador" para o Resize.xlsx (Excel na Web > Automatizar > Novo script)
// Uso: na folha "Schedule (Resize)", selecione a(s) linha(s) das folhas entregues ao prestador e Executar.
// Resultado: coluna X = "Prestador" com fundo amarelo.

function main(workbook: ExcelScript.Workbook) {
  const sel = workbook.getSelectedRange();
  const ws = sel.getWorksheet();
  if (ws.getName() !== "Schedule (Resize)") {
    console.log('Abra a folha "Schedule (Resize)" e selecione as linhas.');
    return;
  }
  const marcadas: string[] = [];
  for (let r = sel.getRowIndex(); r < sel.getRowIndex() + sel.getRowCount(); r++) {
    const folha = ws.getCell(r, 2).getText().trim();       // C - Folha N
    if (!/^Folha\s*\d+/i.test(folha)) continue;
    const x = ws.getCell(r, 23);                            // X
    x.setValue("Prestador");
    x.getFormat().getFill().setColor("#FFFF00");
    marcadas.push(folha);
  }
  console.log(marcadas.length
    ? `Entregue ao prestador: ${marcadas.join(", ")} (coluna X = Prestador).`
    : 'Nenhuma linha com "Folha N" na seleção.');
}
