// Office Script "Recebido" para o Resize.xlsx (Excel na Web > separador Automatizar > Novo script)
// Uso: na folha "Schedule (Resize)", selecione a(s) linha(s) das folhas recebidas
// (basta uma célula de cada linha) e carregue em Executar.
// Resultado: coluna X = "CSP1" com fundo verde.

function main(workbook: ExcelScript.Workbook) {
  marcar(workbook, "CSP1", "#92D050", "Recebido");
}

function marcar(workbook: ExcelScript.Workbook, texto: string, cor: string, acao: string) {
  const NOME_FOLHA = "Schedule (Resize)";
  const COL_FOLHA = 2;   // C - Lotes (Folha N)
  const COL_X = 23;      // X - CSP1 / Prestador

  const sel = workbook.getSelectedRange();
  const ws = sel.getWorksheet();
  if (ws.getName() !== NOME_FOLHA) {
    console.log(`Abra a folha "${NOME_FOLHA}" e selecione as linhas.`);
    return;
  }
  const marcadas: string[] = [];
  for (let r = sel.getRowIndex(); r < sel.getRowIndex() + sel.getRowCount(); r++) {
    const folha = ws.getCell(r, COL_FOLHA).getText().trim();
    if (!/^Folha\s*\d+/i.test(folha)) continue;
    const x = ws.getCell(r, COL_X);
    x.setValue(texto);
    x.getFormat().getFill().setColor(cor);
    marcadas.push(folha);
  }
  console.log(marcadas.length
    ? `${acao}: ${marcadas.join(", ")} (coluna X = ${texto}).`
    : "Nenhuma linha com \"Folha N\" na seleção.");
}
