' ME21N - cria pedido a partir de uma requisi��o de compra
' 1) No Programa Resize carregue em "Criar pedido ME21N" (copia a requisi��o)
' 2) Com o SAP aberto, fa�a duplo clique neste ficheiro
' O script abre a ME21N, escolhe "Requisi��es de compra", preenche
' a requisi��o e o centro CSP1, executa (F8) e adota a requisi��o para o pedido.
Option Explicit

Const CENTRO = "CSP1"
Dim app, ses, req

' ---------- ligar � sess�o SAP aberta ----------
On Error Resume Next
Set app = GetObject("SAPGUI").GetScriptingEngine
If Err.Number <> 0 Or Not IsObject(app) Then
  MsgBox "N�o encontrei o SAP aberto." & vbCrLf & "Abra o SAP (PRO 100) e tente de novo." & vbCrLf & vbCrLf & _
         "Se o SAP estiver aberto, o 'scripting' do SAP GUI pode estar desativado.", vbExclamation, "ME21N"
  WScript.Quit
End If
Set ses = app.ActiveSession
If ses Is Nothing Then Set ses = app.Children(0).Children(0)
If Err.Number <> 0 Or ses Is Nothing Then
  MsgBox "N�o encontrei nenhuma sess�o SAP com login feito.", vbExclamation, "ME21N"
  WScript.Quit
End If
Err.Clear
On Error GoTo 0

' ---------- requisi��o: �rea de transfer�ncia ou pedir ----------
req = Trim(LerClipboard())
If Not EhRequisicao(req) Then
  req = Trim(InputBox("N� da requisi��o de compra (10 d�gitos, come�a por 10):", "ME21N", ""))
End If
If Not EhRequisicao(req) Then
  MsgBox "Requisi��o inv�lida: '" & req & "'", vbExclamation, "ME21N"
  WScript.Quit
End If

' ---------- abrir ME21N ----------
ses.StartTransaction "ME21N"
WScript.Sleep 300

' ativar a s�ntese de documentos se estiver desligada
If Not Existe("wnd[0]/shellcont") Then
  Dim b
  Set b = BotaoPorTexto(ses.findById("wnd[0]/tbar[1]"), "ntese de doc")
  If Not b Is Nothing Then b.press
  WScript.Sleep 300
End If
If Not Existe("wnd[0]/shellcont") Then Falhar "N�o consegui abrir a s�ntese de documentos."

Dim cont, tb, tree, i, id
Set cont = ses.findById("wnd[0]/shellcont")
Set tb = ProcurarShell(cont, "Toolbar")
If tb Is Nothing Then Falhar "N�o encontrei a barra da s�ntese de documentos."

' ---------- variante de sele��o: Requisi��es de compra ----------
Dim menuId : menuId = ""
For i = 0 To tb.ButtonCount - 1
  If InStr(1, tb.GetButtonType(i), "Menu", vbTextCompare) > 0 Then menuId = tb.GetButtonId(i) : Exit For
Next
If menuId = "" Then Falhar "N�o encontrei o bot�o da variante de sele��o."
tb.pressContextButton menuId
tb.selectContextMenuItemByText "Requisi��es de compra"
WScript.Sleep 400

' ---------- preencher requisi��o + centro e executar (F8) ----------
Dim w, usr
Set w = ses.ActiveWindow
Set usr = w.findById("usr")
If Not PreencherPorRotulo(usr, "requisi��o de compra", req) Then Falhar "N�o encontrei o campo 'N� requisi��o de compra'."
PreencherPorRotulo usr, "Centro", CENTRO
w.sendVKey 8
WScript.Sleep 600

' ---------- adotar a requisi��o para o pedido ("cesto") ----------
Set tree = ProcurarShell(ses.findById("wnd[0]/shellcont"), "Tree")
If tree Is Nothing Then Falhar "A requisi��o " & req & " n�o apareceu na s�ntese."

Dim keys, k, alvo : alvo = ""
Set keys = tree.GetAllNodeKeys
For Each k In keys
  If InStr(TextoNo(tree, k), req) > 0 Then alvo = k : Exit For
Next
If alvo = "" Then
  If keys.Count = 0 Then Falhar "A requisi��o " & req & " n�o foi encontrada (j� tem pedido ou n�o � do centro " & CENTRO & "?)."
  alvo = keys(0)
End If
tree.selectNode alvo

Dim adotar : adotar = ""
Set tb = ProcurarShell(ses.findById("wnd[0]/shellcont"), "Toolbar")
For i = 0 To tb.ButtonCount - 1
  If InStr(1, tb.GetButtonTooltip(i), "Adot", vbTextCompare) > 0 Or InStr(1, tb.GetButtonTooltip(i), "Adopt", vbTextCompare) > 0 Then
    adotar = tb.GetButtonId(i) : Exit For
  End If
Next
If adotar = "" Then
  MsgBox "A requisi��o " & req & " est� selecionada na s�ntese." & vbCrLf & "Arraste-a para o cesto para a adotar.", vbInformation, "ME21N"
Else
  tb.pressButton adotar
End If
WScript.Quit

' ================= fun��es =================
Function LerClipboard()
  On Error Resume Next
  LerClipboard = CreateObject("htmlfile").ParentWindow.ClipboardData.GetData("text")
  If IsNull(LerClipboard) Then LerClipboard = ""
End Function

Function EhRequisicao(t)
  Dim rx : Set rx = New RegExp
  rx.Pattern = "^10\d{8}$"
  EhRequisicao = rx.Test(t)
End Function

Function Existe(caminho)
  On Error Resume Next
  Dim o : Set o = ses.findById(caminho, False)
  Existe = (Err.Number = 0 And Not o Is Nothing)
  Err.Clear
End Function

Function BotaoPorTexto(barra, parte)
  Dim c : Set BotaoPorTexto = Nothing
  For Each c In barra.Children
    If InStr(1, c.Text & " " & c.Tooltip, parte, vbTextCompare) > 0 Then Set BotaoPorTexto = c : Exit Function
  Next
End Function

Function ProcurarShell(pai, subtipo)
  Dim c, r
  Set ProcurarShell = Nothing
  On Error Resume Next
  For Each c In pai.Children
    If c.Type = "GuiShell" Then
      If InStr(1, c.SubType, subtipo, vbTextCompare) > 0 Then Set ProcurarShell = c : Exit Function
    End If
    If c.ContainerType Then
      Set r = ProcurarShell(c, subtipo)
      If Not r Is Nothing Then Set ProcurarShell = r : Exit Function
    End If
  Next
End Function

' Encontra o r�tulo pelo texto e preenche o primeiro campo � direita, na mesma linha
Function PreencherPorRotulo(pai, rotulo, valor)
  Dim c, lab, campo, melhor
  PreencherPorRotulo = False
  Set lab = Nothing
  For Each c In pai.Children
    If c.Type = "GuiLabel" Or c.Type = "GuiTextField" Then
      If LCase(Trim(c.Text)) = LCase(rotulo) Or (Len(rotulo) > 8 And InStr(1, c.Text, rotulo, vbTextCompare) > 0) Then
        Set lab = c : Exit For
      End If
    End If
  Next
  If lab Is Nothing Then Exit Function
  Set campo = Nothing : melhor = 99999
  For Each c In pai.Children
    If (c.Type = "GuiCTextField" Or c.Type = "GuiTextField") And c.Changeable Then
      If Abs(c.Top - lab.Top) <= 3 And c.Left > lab.Left And c.Left < melhor Then Set campo = c : melhor = c.Left
    End If
  Next
  If campo Is Nothing Then Exit Function
  campo.Text = valor
  PreencherPorRotulo = True
End Function

Function TextoNo(t, k)
  On Error Resume Next
  TextoNo = t.GetNodeTextByKey(k)
  If Err.Number <> 0 Or TextoNo = "" Then
    Err.Clear
    Dim cols, n
    Set cols = t.GetColumnNames
    For Each n In cols
      TextoNo = TextoNo & " " & t.GetItemText(k, n)
    Next
  End If
End Function

Sub Falhar(m)
  MsgBox m, vbExclamation, "ME21N"
  WScript.Quit
End Sub
